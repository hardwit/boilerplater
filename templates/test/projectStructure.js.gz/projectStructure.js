exports.projectStructure = {
  files: [
    ".eslintrc",
    ".gitignore",
    ".htaccess",
    "index.php",
    "package.json"
  ],
  directories: [
    {
      name: "ajax",
      files: ["formHandler.php"]
    },
    {
      name: "src",
      files: [],
      directories: [
        {
          name: "fonts",
          files: [],
          directories: [{
              name: "icons",
              files: []
            }]
        },
        {
          name: "images",
          files: []
        },
        {
          name: "js",
          files: ["Application.es6"],
          directories: [{
              name: "Components",
              files: [
                "VideoGallery.es6",
                "VideoPlayer.es6"
              ]
            }]
        },
        {
          name: "less",
          files: [
            "blocks.less",
            "fonts.less",
            "forms.less",
            "global.less",
            "icons.less",
            "mixins.less",
            "page.less",
            "reset.less",
            "variables.less",
            "wysiwyg.less"
          ],
          directories: [{
              name: "blocks",
              files: []
            }]
        }
      ]
    },
    {
      name: "templates",
      files: [
        "footer.php",
        "header.php"
      ],
      directories: [{
          name: "pages",
          files: []
        }]
    },
    {
      name: "webpack",
      files: [
        "make-webpack-config.js",
        "webpack.config.js",
        "webpack.production.js",
        "webpack.test.js"
      ],
      directories: [{
          name: "custom-loaders",
          files: []
        }]
    }
  ]
}